package com.patrox.fraseday

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {

    private const val CHANNEL_ID = "frase_diaria_silenciosa"
    private const val NOTIF_ID = 1001

    private fun crearCanal(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val existente = manager.getNotificationChannel(CHANNEL_ID)
            if (existente == null) {
                val canal = NotificationChannel(
                    CHANNEL_ID,
                    context.getString(R.string.notif_channel_name),
                    NotificationManager.IMPORTANCE_LOW // sin sonido, sin popup emergente
                ).apply {
                    description = context.getString(R.string.notif_channel_desc)
                    setSound(null, null)
                    enableVibration(false)
                }
                manager.createNotificationChannel(canal)
            }
        }
    }

    fun mostrarFraseSilenciosa(context: Context, frase: String) {
        crearCanal(context)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Frase del día")
            .setContentText(frase)
            .setStyle(NotificationCompat.BigTextStyle().bigText(frase))
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .setAutoCancel(true)
            .build()

        // POST_NOTIFICATIONS se pide en MainActivity antes de llegar acá (Android 13+).
        // Si por algún motivo no está otorgado, evitamos que la app se cierre.
        try {
            NotificationManagerCompat.from(context).notify(NOTIF_ID, notification)
        } catch (e: SecurityException) {
            // Permiso no concedido: no hacemos nada, el widget sigue funcionando igual.
        }
    }
}
