package com.patrox.fraseday

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

class MotivationWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) {
            actualizarWidget(context, appWidgetManager, id)
        }
    }

    override fun onEnabled(context: Context) {
        // Se agrega el primer widget a la pantalla: aseguramos que el trabajo
        // diario esté programado.
        DailyPhraseWorker.programarTrabajoDiario(context)
    }

    companion object {
        fun actualizarWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val frase = PhraseRepository.fraseDeHoy(context)
            val views = RemoteViews(context.packageName, R.layout.widget_motivation)
            views.setTextViewText(R.id.widgetFraseText, frase)
            manager.updateAppWidget(widgetId, views)
        }

        fun actualizarTodosLosWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                android.content.ComponentName(context, MotivationWidgetProvider::class.java)
            )
            for (id in ids) {
                actualizarWidget(context, manager, id)
            }
        }
    }
}
