package com.patrox.fraseday

import android.content.Context
import androidx.work.*
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.concurrent.TimeUnit

class DailyPhraseWorker(context: Context, params: WorkerParameters) :
    Worker(context, params) {

    override fun doWork(): Result {
        // Al ejecutarse, PhraseRepository detecta que cambió el día y rota la frase.
        val frase = PhraseRepository.fraseDeHoy(applicationContext)

        // 1) Actualizar todos los widgets en pantalla
        MotivationWidgetProvider.actualizarTodosLosWidgets(applicationContext)

        // 2) Notificación silenciosa (si el usuario la activó en ajustes)
        val prefs = applicationContext.getSharedPreferences("frase_prefs", Context.MODE_PRIVATE)
        val notifActivada = prefs.getBoolean("notif_enabled", true)
        if (notifActivada) {
            NotificationHelper.mostrarFraseSilenciosa(applicationContext, frase)
        }

        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "frase_diaria_trabajo"

        /**
         * Programa un trabajo periódico (cada 24h) cuya primera ejecución cae
         * justo a la medianoche siguiente, hora de Buenos Aires.
         */
        fun programarTrabajoDiario(context: Context) {
            val zona = PhraseRepository.ZONA_ARGENTINA
            val ahora = LocalDateTime.now(zona)
            val proximaMedianoche = LocalDateTime.of(
                LocalDate.now(zona).plusDays(1),
                LocalTime.MIDNIGHT
            )
            val demora = Duration.between(ahora, proximaMedianoche).toMillis()

            val request = PeriodicWorkRequestBuilder<DailyPhraseWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(demora, TimeUnit.MILLISECONDS)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        /** Fuerza una ejecución inmediata, útil para el botón "Probar ahora". */
        fun ejecutarAhora(context: Context) {
            val request = OneTimeWorkRequestBuilder<DailyPhraseWorker>().build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
