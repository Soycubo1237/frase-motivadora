package com.patrox.fraseday

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.patrox.fraseday.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val pedirPermisoNotificaciones =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Pide permiso de notificaciones en Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                pedirPermisoNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Programa el trabajo diario (no hace nada si ya estaba programado)
        DailyPhraseWorker.programarTrabajoDiario(this)

        mostrarFraseActual()

        val prefs = getSharedPreferences("frase_prefs", Context.MODE_PRIVATE)
        binding.switchNotificacion.isChecked = prefs.getBoolean("notif_enabled", true)
        binding.switchNotificacion.setOnCheckedChangeListener { _, activado ->
            prefs.edit().putBoolean("notif_enabled", activado).apply()
        }

        binding.btnProbar.setOnClickListener {
            DailyPhraseWorker.ejecutarAhora(this)
            binding.root.postDelayed({ mostrarFraseActual() }, 800)
        }
    }

    private fun mostrarFraseActual() {
        binding.tvFraseActual.text = PhraseRepository.fraseDeHoy(this)
    }

    override fun onResume() {
        super.onResume()
        mostrarFraseActual()
    }
}
