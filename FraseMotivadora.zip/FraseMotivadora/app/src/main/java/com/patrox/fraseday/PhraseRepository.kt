package com.patrox.fraseday

import android.content.Context
import java.time.ZoneId
import java.time.LocalDate

/**
 * Lista de frases y lógica para elegir "la frase de hoy" según el calendario
 * de Buenos Aires. Editá esta lista con las frases que quieras.
 */
object PhraseRepository {

    private const val PREFS = "frase_prefs"
    private const val KEY_LAST_INDEX = "last_index"
    private const val KEY_LAST_DATE = "last_date"

    val ZONA_ARGENTINA: ZoneId = ZoneId.of("America/Argentina/Buenos_Aires")

    private val frases = listOf(
        "Un paso pequeño hoy vale más que un plan perfecto que nunca empieza.",
        "No necesitas sentirte listo para empezar, necesitas empezar para sentirte listo.",
        "La disciplina es elegir entre lo que quieres ahora y lo que quieres de verdad.",
        "Cada día es una hoja nueva. Escribí algo que valga la pena releer.",
        "El progreso no siempre se ve, pero se acumula.",
        "Hazlo aunque no tengas ganas: las ganas llegan después de empezar.",
        "Comparate solo con quien eras ayer.",
        "Lo difícil de hoy es la fuerza de mañana.",
        "No cuentes los días, haz que los días cuenten.",
        "Una meta sin fecha es solo un deseo.",
        "El cansancio pasa, haber abandonado, no.",
        "Todo experto fue alguna vez un principiante que no se rindió.",
        "Tu única competencia real sos vos mismo de ayer.",
        "La motivación te arranca, el hábito te sostiene.",
        "No se trata de tener tiempo, se trata de hacer tiempo.",
        "El miedo se combate haciendo, no pensando.",
        "Cada error es información, no una sentencia.",
        "Empieza donde estás, con lo que tenés.",
        "La constancia le gana al talento cuando el talento no es constante.",
        "Hoy es un buen día para intentarlo una vez más."
    )

    /**
     * Devuelve la frase que corresponde al día de hoy (hora Buenos Aires).
     * Usa la fecha como semilla, así todos los componentes (widget y notificación)
     * muestran siempre la misma frase durante las 24 horas del día.
     */
    fun fraseDeHoy(context: Context): String {
        val hoy: LocalDate = LocalDate.now(ZONA_ARGENTINA)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val fechaGuardada = prefs.getString(KEY_LAST_DATE, null)

        val indice: Int = if (fechaGuardada == hoy.toString()) {
            // Ya elegimos frase para hoy, no la cambiamos hasta mañana
            prefs.getInt(KEY_LAST_INDEX, 0)
        } else {
            // Nuevo día: pasamos a la siguiente frase (rota la lista, sin repetir
            // hasta agotarla)
            val anterior = prefs.getInt(KEY_LAST_INDEX, -1)
            val nuevo = (anterior + 1) % frases.size
            prefs.edit()
                .putInt(KEY_LAST_INDEX, nuevo)
                .putString(KEY_LAST_DATE, hoy.toString())
                .apply()
            nuevo
        }
        return frases[indice]
    }
}
